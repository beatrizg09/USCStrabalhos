
package testavendedor;


public class TestaVendedor {

    
    public static void main(String[] args) {
        
    }
    
}
